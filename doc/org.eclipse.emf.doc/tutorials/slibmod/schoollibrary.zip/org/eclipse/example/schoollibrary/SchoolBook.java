package org.eclipse.example.schoollibrary;

import org.eclipse.example.library.Book;

/**
 * @model
 */
public interface SchoolBook extends Book, Asset
{
}
