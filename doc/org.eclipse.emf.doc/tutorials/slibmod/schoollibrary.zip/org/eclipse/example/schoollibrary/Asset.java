package org.eclipse.example.schoollibrary;

/**
 * @model
 */
public interface Asset
{
  /**
   * @model
   */
  float getValue();
}
