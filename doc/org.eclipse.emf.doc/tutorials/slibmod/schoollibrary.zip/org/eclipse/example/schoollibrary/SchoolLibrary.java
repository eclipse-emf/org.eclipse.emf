package org.eclipse.example.schoollibrary;

import org.eclipse.example.library.Library;

/**
 * @model
 */
public interface SchoolLibrary extends Library
{
  /**
   * @model
   */
  String getLocation();
}
